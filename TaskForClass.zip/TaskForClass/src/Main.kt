import kotlin.math.*
fun main() {
    val vertexOne = Point(4.0,8.0)
    val vertexTwo = Point(9.0,10.0)
    val vertexThree = Point(14.0,6.0)
    val triangle = Triangles(vertexOne,vertexTwo,vertexThree)

    triangle.printTriangle()


}

fun LengthCalculation(x1: Double, y1: Double, x2: Double, y2: Double): Double{
    return sqrt((x2 - x1).pow(2) + (y2 - y1).pow(2))
}

class Point(var x: Double, var y: Double){
    init {
        x = round(x * 100) / 100
        y = round((y / 100) * 100)
    }
}

class Triangles(
    FirstVertex: Point,
    SecondVertex: Point,
    ThirdVertex: Point


) {
    var sideProperty1: Double = 0.0
    var sideProperty2: Double = 0.0
    var sideProperty3: Double = 0.0
    var FirstVertex = FirstVertex
    var SecondVertex = SecondVertex
    var ThirdVertex = ThirdVertex
    init{
         sideProperty1 = round(LengthCalculation(
            FirstVertex.x,
            FirstVertex.y,
            SecondVertex.x,
            SecondVertex.y
        )* 100) / 100
        sideProperty2 = round(LengthCalculation(
            ThirdVertex.x,
            ThirdVertex.y,
            SecondVertex.x,
            SecondVertex.y
        ) * 100) / 100
        sideProperty3 = round(LengthCalculation(
            FirstVertex.x,
            FirstVertex.y,
            ThirdVertex.x,
            ThirdVertex.y
        ) * 100) / 100
        val arraySides: DoubleArray = doubleArrayOf(sideProperty1, sideProperty2, sideProperty3)
        arraySides.sort()
        if (arraySides[0] + arraySides[1] == arraySides[2] ){
            throw IllegalArgumentException("Точки лежат на одной прямой, треугольник не может быть построен")
        }

    }


    fun setValuesInput(){
        println("Ввод значений для первой вершины:")
        print("Введите значение x: ")
        FirstVertex.x = round(readln().toDouble() * 100) / 100
        print("Введите значение y: ")
        FirstVertex.y = round(readln().toDouble() * 100) / 100

        println("Ввод значений для второй вершины:")
        print("Введите значение x: ")
        SecondVertex.x = round(readln().toDouble() * 100) / 100
        print("Введите значение y: ")
        SecondVertex.y = round(readln().toDouble() * 100) / 100



        println("Ввод значений для третьей вершины:")
        print("Введите значение x: ")
        ThirdVertex.x = round(readln().toDouble() * 100) / 100
        print("Введите значение y: ")
        ThirdVertex.y = round(readln().toDouble() * 100) / 100

        sideProperty1 = LengthCalculation(
            FirstVertex.x,
            FirstVertex.y,
            SecondVertex.x,
            SecondVertex.y)
        sideProperty2 = LengthCalculation(
            SecondVertex.x,
            SecondVertex.y,
            ThirdVertex.x,
            ThirdVertex.y)
        sideProperty3 = LengthCalculation(
            ThirdVertex.x,
            ThirdVertex.y,
            FirstVertex.x,
            FirstVertex.y)
        if (sideProperty1 + sideProperty2 == sideProperty3 ){
            throw IllegalArgumentException("Точки лежат на одной прямой, треугольник не может быть построен")
        }
    }


    fun printTriangle(){
        val arraySides: DoubleArray = doubleArrayOf(sideProperty1,sideProperty2,sideProperty3)
        arraySides.sort()
        if (sideProperty1 + sideProperty2 > sideProperty3 ||
            sideProperty1 + sideProperty3 > sideProperty2 ||
            sideProperty2 + sideProperty3 > sideProperty1
            ){
            println("Ваш треугольник существует...")
            if (arraySides[0].pow(2) + arraySides[1].pow(2) == arraySides[2].pow(2)){
                println("Ваш треугольник прямоугольный")
            }else if (arraySides[0] == arraySides[1] && arraySides[1] == arraySides[2]){
                println("Ваш треугольник равносторонний")
            } else if ((arraySides[0] == arraySides[1] && arraySides[0] != arraySides[2])||
                (arraySides[0] == arraySides[2] && arraySides[0] != arraySides[1]) ||
                (arraySides[2] == arraySides[1] && arraySides[0] != arraySides[2])
                ){
                println("Ваш треугольник равнобедренный")
            }


            println("\t Первая сторона треугольника равна: $sideProperty1")
            println("\t Вторая сторона треугольника равна: $sideProperty2")
            println("\t Третья сторона треугольника равна: $sideProperty3")
            print("\n")
            println("\tПериметр треугольника равен: ${perimeterCalculation()}")
            println("\tПлощадь треугольника равна: ${areaCalculation()}")
        }
    }

    fun perimeterCalculation(): Double{
        return sideProperty1 + sideProperty2 + sideProperty3
    }

    fun areaCalculation(): Double{
        val p: Double = perimeterCalculation() / 2
        return sqrt(p * (p - sideProperty1) * (p - sideProperty2) * (p - sideProperty3))
    }




}